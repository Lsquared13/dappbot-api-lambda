module.exports = {
  cognito : require('./cognito'),
  dynamoDB : require('./dynamoDB'),
  sqs : require('./sqs'),
  names : require('./names')
}